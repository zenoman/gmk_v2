<?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('title',$webset->webName); ?>
<?php $__env->startSection('favicon'); ?>
<link rel="shortcut icon" type="image" href="<?php echo e(asset('img/setting/'.$webset->ico)); ?>">
<?php $__env->stopSection(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startSection('css'); ?>
<!-- DataTables CSS -->
    <link href="<?php echo e(asset('assets/vendor/datatables-plugins/dataTables.bootstrap.css')); ?>" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="<?php echo e(asset('assets/vendor/datatables-responsive/dataTables.responsive.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Omset</h1>
            </div>
        </div>
            <div class="row">
                <div class="col-lg-12">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <button id="btncetak" class="btn btn-primary">
                        <i class="fa fa-print"></i> Print
                    </button>

                    <a href="<?php echo e(url('/omset/export')); ?>" class="btn btn-success"><i class="fa fa-file-excel-o"></i> Exsport Excel</a>

                    <br><br>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                        List Data Omset
                        </div>
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Pemasukan Online</th>
                                        <th>Pemasukan Offline</th>
                                        <th>Pemasukan Lain</th>
                                        <th>Pengeluaran</th>
                                        <th>Laba</th>
                                        <th>bulan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1;?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $no = $i++;?>
                                    <tr>
                        <td><?php echo e($no); ?></td>
                        <td><?php echo e("Rp ". number_format($row->pemasukan_online,0,',','.')); ?></td>
                        <td><?php echo e("Rp ". number_format($row->pemasukan_offline,0,',','.')); ?></td>
                        <td><?php echo e("Rp ". number_format($row->pemasukan_lain,0,',','.')); ?></td>
                        <td class="text-danger"><?php echo e("Rp ". number_format($row->pengeluaran,0,',','.')); ?></td>
                        <td><?php echo e("Rp ". number_format($row->omset,0,',','.')); ?></td>
                        <td><?php echo e($row->bulan); ?>-<?php echo e($row->tahun); ?></td>
                    </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="hidden_div" style="display:none;">
            <h3 align="center">
                Omset Bulanan
            </h3>
            <table width="100%" border="1">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Pemasukan Online</th>
                        <th>Pemasukan Offline</th>
                        <th>Pemasukan Lain</th>
                        <th>Pengeluaran</th>
                        <th>Laba</th>
                        <th>Bulan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1;?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $no = $i++;?>
                    <tr>
                        <td><?php echo e($no); ?></td>
                        <td><?php echo e("Rp ". number_format($row->pemasukan_online,0,',','.')); ?></td>
                        <td><?php echo e("Rp ". number_format($row->pemasukan_offline,0,',','.')); ?></td>
                        <td><?php echo e("Rp ". number_format($row->pemasukan_lain,0,',','.')); ?></td>
                        <td><?php echo e("Rp ". number_format($row->pengeluaran,0,',','.')); ?></td>
                        <td><?php echo e("Rp ". number_format($row->omset,0,',','.')); ?></td>
                        <td><?php echo e($row->bulan); ?>-<?php echo e($row->tahun); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('js'); ?>
        <script src="<?php echo e(asset('assets/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendor/datatables-plugins/dataTables.bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendor/datatables-responsive/dataTables.responsive.js')); ?>"></script>
        
        <script>
            $(document).ready(function(){
                $('#dataTables-example').DataTable({
                responsive: true });
            });
        //==================================================
        $('#btncetak').click(function(){
        var divToPrint=document.getElementById('hidden_div');
        var newWin=window.open('','Print-Window');
        newWin.document.open();
        newWin.document.write('<html><body onload="window.print();window.close()">'+divToPrint.innerHTML+'</body></html>');
        newWin.document.close();
        });
        </script>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>