<?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('title',$webset->webName); ?>
<?php $__env->startSection('favicon'); ?>
<link rel="shortcut icon" type="image" href="<?php echo e(asset('img/setting/'.$webset->ico)); ?>">
<?php $__env->stopSection(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startSection('css'); ?>
<!-- DataTables CSS -->
    <link href="<?php echo e(asset('assets/vendor/datatables-plugins/dataTables.bootstrap.css')); ?>" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="<?php echo e(asset('assets/vendor/datatables-responsive/dataTables.responsive.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<script type="text/javascript">
     function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
      
</script>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Detail Pembelian</h1>

                </div>
            </div>
            <div class="row">
                
                <div class="col-lg-12">
                    <?php $__currentLoopData = $kode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="well well-sm">
                        <h4>Faktur : <?php echo e($kd->faktur); ?></h4>
                        <table>
                            <tr>
                                <td>Tanggal Beli</td>
                                <td>&nbsp;:&nbsp;<?php echo e($kd->tgl); ?></td>
                            </tr>
                            <tr>
                               <td>Pembeli</td>
                                <td>&nbsp;:&nbsp;
                                  <span id="username_asli">
                                      <?php
                                 $datauser = DB::table('tb_users')
                                 ->where('id',$kd->iduser)
                                 ->get();
                                 ?>
                                 <?php $__currentLoopData = $datauser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($usr->username); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </span>
                               
                                </td>
                            </tr>
                            <tr>
                                <td>Metode Pembayaran</td>
                                <td>&nbsp;:&nbsp;
                                    <?php
                                 $databank = DB::table('tb_bank')
                                 ->where('id',$kd->pembayaran)
                                 ->get();
                                 ?>
                                 <?php $__currentLoopData = $databank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($bank->nama_bank); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                            <tr>
                                <td>No Telp</td>
                                <td>&nbsp;:&nbsp;
                                  <span id="telp_asli">
                                    <?php echo e($kd->telp); ?>

                                  </span>
                                </td>
                            </tr>
                            <tr>
                                <td>Alamat Tujuan</td>
                                <td>&nbsp;:&nbsp;
                                  <span id="alamat_asli">
                                    <?php echo e($kd->alamat_tujuan); ?>

                                  </span>
                                </td>
                            </tr>
                            <tr>
                                <td>Keterangan</td>
                                <td>&nbsp;:&nbsp;<?php echo e($kd->keterangan); ?></td>
                            </tr>
                        </table>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            List barang yang dibeli
                        </div>
                        <div class="panel-body">

                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode Barang</th>
                                        <th>Nama Barang</th>
                                        <th>Warna</th>
                                        <th>Jumlah</th>
                                        <th>harga</th>
                                        <th>diskon</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                     $no =1;
                                    ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($row->kode_barang); ?></td>
                                        <td><?php echo e($row->barang); ?></td>
                                        <td><?php echo e($row->varian); ?></td>
                                        <td><?php echo e($row->jumlah); ?> Pcs</td>
                                        <td class="text-right"><?php echo e("Rp ". number_format($row->harga,0,',','.')); ?></td>
                                        <td><?php echo e($row->diskon); ?>%</td>
                                        <td class="text-right">
                                            <?php echo e("Rp ". number_format($row->total,0,',','.')); ?>

                                        </td>
                                    </tr>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                              </table>
                            <div class="well well-sm text-right">

                                <h4><b>Subtotal</b> : <?php echo e("Rp ". number_format($kd->total,0,',','.')); ?></h4>
                                <h4><b>Potongan</b> : <?php echo e("Rp ". number_format($kd->potongan,0,',','.')); ?></h4>
                                <h4><b>Ongkir</b> : <?php echo e("Rp ". number_format($kd->ongkir,0,',','.')); ?></h4>
                                <h3><b>Total Akhir</b> : <?php echo e("Rp ". number_format($kd->total_akhir,0,',','.')); ?></h3>
                             </div>
                              <button id="btncetak" class="btn btn-primary">
                                cetak nota
                             </button>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                        Cetak lembar pengiriman
                        </div>
                        <div class="panel-body">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs">
                                <li class="active"><a href="#home" data-toggle="tab" aria-expanded="true">Pembeli Biasa</a>
                                </li>
                                <li class=""><a href="#profile" data-toggle="tab" aria-expanded="false">Reseller</a>
                                </li>
                            </ul>

                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane fade active in" id="home">
                                    <h4>Lembar Pengiriman Pembeli Biasa</h4>
                                    <div class="form-group">
                                            <label>Penerima</label>
                                            <input class="form-control" id="penerima">
                                            <p class="help-block">Opsional, bila kosong data penerima akan di isi oleh nama pembeli.</p>
                                        </div>
                                        <div class="form-group">
                                            <label>Telfon Penerima</label>
                                            <input class="form-control" id="telfonpenerima" onkeypress="return isNumberKey(event)">
                                            <p class="help-block">Opsional, bila kosong data telfon penerima akan di isi oleh telfon akun pembeli.</p>
                                        </div>
                                        <div class="form-group">
                                            <label>Alamat Penerima</label>
                                            <textarea class="form-control" rows="3" id="alamat"></textarea>
                                             <p class="help-block">Opsional, bila kosong data alamat penerima akan di isi oleh alamat yang di isi pembeli saat melakukan pembelian.</p>
                                        </div>
                                        <div class="form-group">
                                            <label>Keterangan Paket</label>
                                            <textarea class="form-control" rows="3" id="keterangan"></textarea>
                                             <p class="help-block">Sangat berguna bagi pihak pengiriman barang untuk mengerti isi paket, agar paket diperlakukan lebih berhati-hati.</p>
                                        </div>
                                             
                             <button class="btn btn-success" id="btncetakpengiriman">
                                 cetak lembar pengiriman
                             </button>
                             <button class="btn btn-warning" id="btnbersih">
                                bersih
                             </button>
                             <a onclick="window.history.go(-1);" class="btn btn-danger pull-right">Kembali</a>
                                </div>
                                <div class="tab-pane fade" id="profile">
                                    <h4>Lembar Pengiriman Reseller</h4>
                                    <div class="row">
                                     <div class="form-group col-md-6">
                                            <label>Pengirim</label>
                                            <input class="form-control" id="r_pengirim">
                                            <p class="help-block">Opsional, bila kosong data penerima akan di isi oleh nama pembeli.</p>
                                        </div>
                                     <div class="form-group col-md-6">
                                            <label>Penerima</label>
                                            <input class="form-control" id="r_penerima">
                                            <p class="help-block">*Wajib di isi</p>
                                        </div>
                                    <div class="form-group col-md-6">
                                            <label>Telfon Pengirim</label>
                                            <input class="form-control" id="r_telfonpengirim" onkeypress="return isNumberKey(event)">
                                            <p class="help-block">bila kosong data telfon penerima di isi dengan telfon akun pembeli.</p>
                                        </div>
                                      <div class="form-group col-md-6">
                                            <label>Telfon Penerima</label>
                                            <input class="form-control" id="r_telfonpenerima" onkeypress="return isNumberKey(event)">
                                            <p class="help-block">*Wajib di isi</p>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label>Alamat Pengirim</label>
                                            <textarea class="form-control" rows="3" id="r_alamatpengirim"></textarea>
                                             <p class="help-block">bila kosong data alamat penerima akan di isi oleh alamat yang di isi pembeli saat melakukan pembelian.</p>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label>Alamat Penerima</label>
                                            <textarea class="form-control" rows="3" id="r_alamatpenerima"></textarea>
                                             <p class="help-block">Opsional, bila kosong data alamat penerima akan di isi oleh alamat yang di isi pembeli saat melakukan pembelian.</p>
                                        </div>
                                        <div class="form-group col-md-12">
                                            <label>Keterangan Paket</label>
                                            <textarea class="form-control" rows="3" id="r_keterangan"></textarea>
                                             <p class="help-block">Sangat berguna bagi pihak pengiriman barang untuk mengerti isi paket, agar paket diperlakukan lebih berhati-hati.</p>
                                        </div>
                                             
                             
                                    </div>
                                    <button class="btn btn-success" id="r_btncetakpengiriman">
                                 cetak lembar pengiriman
                             </button>
                             <button class="btn btn-warning" id="r_btnbersih">
                                bersih
                             </button>
                             <a onclick="window.history.go(-1);" class="btn btn-danger pull-right">Kembali</a> 
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="hidden_div_reseller" style="display: none;">
            <div style="border-style: solid;">
                <br>
                <?php $__currentLoopData = $kode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <table width="100%">
                    <tr>
                        <td width="20%">
                            <b>
                                Pengirim
                            </b>
                        </td>
                        <td width="3%">&nbsp;:&nbsp;</td>
                        <td id="r_cetakpengirim">
                             <?php
                                 $datauser = DB::table('tb_users')
                                 ->where('id',$kd->iduser)
                                 ->get();
                                 ?>
                                 <?php $__currentLoopData = $datauser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($usr->username); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        
                    </tr>
                    <tr>
                        <td width="20%"><b>Alamat Pengirim</b></td>
                        <td width="3%">&nbsp;:&nbsp;</td>
                        <td id="r_cetakalamatpengirim"><?php echo e($kd->alamat_tujuan); ?></td>
                    </tr>
                    <tr>
                        <td width="20%">
                        <b>No.Telpon Pengirim</b>
                        </td>
                        <td width="3%">&nbsp;:&nbsp;</td>
                        <td id="r_cetaktelppengirim"><?php echo e($kd->telp); ?></td>
                    </tr>
                </table>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <hr>
                  <table width="100%">
                    <tr>
                        <td width="20%">
                            <b>
                              Penerima
                            </b>
                        </td>
                        <td width="3%">&nbsp;:&nbsp;</td>
                        <td id="r_cetakpenerima">
                            
                        </td>
                        
                    </tr>
                    <tr>
                        <td width="20%"><b>Alamat Penerima</b></td>
                        <td width="3%">&nbsp;:&nbsp;</td>
                        <td id="r_cetakalamatpenerima"></td>
                    </tr>
                    <tr>
                        <td width="20%">
                        <b>No.Telpon Penerima</b>
                        </td>
                        <td width="3%">&nbsp;:&nbsp;</td>
                        <td id="r_cetaktelppenerima"></td>
                    </tr>
                </table>
                <p id="r_cetakketerangan"></p>
            </div>
        </div>
        <div id="hidden_div_pengiriman" style="display: none;">
            <div style="border-style: solid;">
                <br>
                <?php $__currentLoopData = $kode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <table width="100%">
                    <tr>
                        <td width="15%">
                            <b>
                                Kepada
                            </b>
                        </td>
                        <td width="3%">&nbsp;:&nbsp;</td>
                        <td id="cetakpenerima">
                             <?php
                                 $datauser = DB::table('tb_users')
                                 ->where('id',$kd->iduser)
                                 ->get();
                                 ?>
                                 <?php $__currentLoopData = $datauser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($usr->username); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        
                    </tr>
                    <tr>
                        <td width="15%"><b>Alamat</b></td>
                        <td width="3%">&nbsp;:&nbsp;</td>
                        <td id="cetakalamat"><?php echo e($kd->alamat_tujuan); ?></td>
                    </tr>
                    <tr>
                        <td width="15%">
                        <b>No.Telpon</b>
                        </td>
                        <td width="3%">&nbsp;:&nbsp;</td>
                        <td id="cetaktelp"><?php echo e($kd->telp); ?></td>
                    </tr>
                </table>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <hr>
                <p id="cetakketerangan"></p>
               
                <?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p align="center">
                <b><?php echo e($webset->webName); ?></b><br>
                <b>Pusat Grosir pakaian Terbaru, Termurah & Berkwalitas</b><br>
                <b><?php echo e($webset->alamat); ?></b><br>
                 kontak 1&nbsp;:&nbsp;<?php echo e($webset->kontak1); ?> ||
                 kontak 2&nbsp;:&nbsp;<?php echo e($webset->kontak2); ?> ||
                 kontak 3&nbsp;:&nbsp;<?php echo e($webset->kontak3); ?> 
                </p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
        <div id="hidden_div" style="display: none;">
                    <?php $__currentLoopData = $kode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <table width="100%">
                            <tr>
                                <td><b>Faktur</b></td>
                                <td>&nbsp;:&nbsp;</td>
                                <td><?php echo e($kd->faktur); ?></td>
                                <td align="right">
                                    <b>Pencetak</b>
                                </td>
                                <td>&nbsp;:&nbsp;</td>
                                <td align="right"><?php echo e(Session::get('username')); ?></td>
                            </tr>
                            <tr>
                                <td><b>Tanggal Beli</b></td>
                                <td>&nbsp;:&nbsp;</td>
                                <td><?php echo e($kd->tgl); ?></td>
                                <td align="right">
                                    <b>Pembayaran</b>
                                </td>
                                <td>&nbsp;:&nbsp;</td>
                                <td align="right">
                                    <?php
                                 $databank = DB::table('tb_bank')
                                 ->where('id',$kd->pembayaran)
                                 ->get();
                                 ?>
                                 <?php $__currentLoopData = $databank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($bank->nama_bank); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                            <tr>
                               <td><b>Pembeli</b></td>
                                <td>&nbsp;:&nbsp;</td>
                                <td>
                                 <?php
                                 $datauser = DB::table('tb_users')
                                 ->where('id',$kd->iduser)
                                 ->get();
                                 ?>
                                 <?php $__currentLoopData = $datauser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($usr->username); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td align="right"><b>No.telp</b></td>
                                <td>&nbsp;:&nbsp;</td>
                                <td align="right"><?php echo e($kd->telp); ?></td>                            </tr>
                            
                            <tr>
                                <td><b>Alamat Tujuan</b></td>
                                <td>&nbsp;:&nbsp;</td>
                                <td colspan="3"><?php echo e($kd->alamat_tujuan); ?></td>
                                
                            </tr>
                            <tr>
                                <td><b>Keterangan</b></td>
                                <td>&nbsp;:&nbsp;</td>
                                <td colspan="3"><?php echo e($kd->keterangan); ?></td>
                                
                            </tr>
                        </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <table width="100%" border="1">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode Barang</th>
                                        <th>Nama Barang</th>
                                        <th>Warna</th>
                                        <th>Jumlah</th>
                                        <th>harga</th>
                                        <th>diskon</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                     $no =1;
                                    ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($row->kode_barang); ?></td>
                                        <td><?php echo e($row->barang); ?></td>
                                        <td><?php echo e($row->varian); ?></td>
                                        <td><?php echo e($row->jumlah); ?> Pcs</td>
                                        <td class="text-right"><?php echo e("Rp ". number_format($row->harga,0,',','.')); ?></td>
                                        <td><?php echo e($row->diskon); ?>%</td>
                                        <td class="text-right">
                                            <?php echo e("Rp ". number_format($row->total,0,',','.')); ?>

                                        </td>
                                    </tr>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                              </table>
                            <div align="right">
                            
                                <b>
                                <br>
                                Subtotal : <?php echo e("Rp ". number_format($kd->total,0,',','.')); ?>

                                <br>
                                Ongkir : <?php echo e("Rp ". number_format($kd->ongkir,0,',','.')); ?>

                                <br>
                                Total Akhir : <?php echo e("Rp ". number_format($kd->total_akhir,0,',','.')); ?></b>
                             </div>
                             <hr>
                             <?php $__currentLoopData = $kode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <table width="100%">
                            <tr>
                                <td><b>Faktur</b></td>
                                <td>&nbsp;:&nbsp;</td>
                                <td><?php echo e($kd->faktur); ?></td>
                                <td align="right">
                                    <b>Pencetak</b>
                                </td>
                                <td>&nbsp;:&nbsp;</td>
                                <td align="right"><?php echo e(Session::get('username')); ?></td>
                            </tr>
                            <tr>
                                <td><b>Tanggal Beli</b></td>
                                <td>&nbsp;:&nbsp;</td>
                                <td><?php echo e($kd->tgl); ?></td>
                                <td align="right">
                                    <b>Pembayaran</b>
                                </td>
                                <td>&nbsp;:&nbsp;</td>
                                <td align="right">
                                    <?php
                                 $databank = DB::table('tb_bank')
                                 ->where('id',$kd->pembayaran)
                                 ->get();
                                 ?>
                                 <?php $__currentLoopData = $databank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($bank->nama_bank); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                            <tr>
                               <td><b>Pembeli</b></td>
                                <td>&nbsp;:&nbsp;</td>
                                <td>
                                 <?php
                                 $datauser = DB::table('tb_users')
                                 ->where('id',$kd->iduser)
                                 ->get();
                                 ?>
                                 <?php $__currentLoopData = $datauser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($usr->username); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td align="right"><b>No.telp</b></td>
                                <td>&nbsp;:&nbsp;</td>
                                <td align="right"><?php echo e($kd->telp); ?></td>                            </tr>
                            
                            <tr>
                                <td><b>Alamat Tujuan</b></td>
                                <td>&nbsp;:&nbsp;</td>
                                <td colspan="3"><?php echo e($kd->alamat_tujuan); ?></td>
                                
                            </tr>
                            <tr>
                                <td><b>Keterangan</b></td>
                                <td>&nbsp;:&nbsp;</td>
                                <td colspan="3"><?php echo e($kd->keterangan); ?></td>
                                
                            </tr>
                        </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <table width="100%" border="1">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode Barang</th>
                                        <th>Nama Barang</th>
                                        <th>Warna</th>
                                        <th>Jumlah</th>
                                        <th>harga</th>
                                        <th>diskon</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                     $no =1;
                                    ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($row->kode_barang); ?></td>
                                        <td><?php echo e($row->barang); ?></td>
                                        <td><?php echo e($row->varian); ?></td>
                                        <td><?php echo e($row->jumlah); ?> Pcs</td>
                                        <td class="text-right"><?php echo e("Rp ". number_format($row->harga,0,',','.')); ?></td>
                                        <td><?php echo e($row->diskon); ?>%</td>
                                        <td class="text-right">
                                            <?php echo e("Rp ". number_format($row->total,0,',','.')); ?>

                                        </td>
                                    </tr>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                              </table>
                            <div align="right">
                            
                                <b>
                                <br>
                                Subtotal : <?php echo e("Rp ". number_format($kd->total,0,',','.')); ?>

                                <br>
                                Ongkir : <?php echo e("Rp ". number_format($kd->ongkir,0,',','.')); ?>

                                <br>
                                Total Akhir : <?php echo e("Rp ". number_format($kd->total_akhir,0,',','.')); ?></b>
                             </div>
                             <hr>
        </div>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('js'); ?>
        <!-- DataTables JavaScript -->
        <script src="<?php echo e(asset('assets/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendor/datatables-plugins/dataTables.bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendor/datatables-responsive/dataTables.responsive.js')); ?>"></script>
        <script>
        //==================================================
        $('#btncetak').click(function(){
        
        var print_div = document.getElementById("hidden_div");
var print_area = window.open();
print_area.document.write(print_div.innerHTML);
print_area.document.close();
print_area.focus();
print_area.print();
print_area.close();
        
        });
        $('#btncetakpengiriman').click(function(){
        var foo = "bar";
        if(foo=="bar"){
        var isgood = confirm('Apakah data lembar pengiriman benar ?');
        if(isgood){
            if($('#penerima').val()!=''){
              $('#cetakpenerima').html($('#penerima').val());
            }else{
              $('#cetakpenerima').html($('#username_asli').html());
            }
            if($('#telfonpenerima').val()!=''){
                $('#cetaktelp').html($('#telfonpenerima').val());
            }else{
              $('#cetaktelp').html($('#telp_asli').html());
            }
            if($('#alamat').val()!=''){
              $('#cetakalamat').html($('#alamat').val());
            }else{
              $('#cetakalamat').html($('#alamat_asli').html());
            }
            if($('#keterangan').val()!=''){
              $('#cetakketerangan').html('<b>Keterangan : </b>'+$('#keterangan').val()+' <hr>');
            }else{
              $('#cetakketerangan').html('');
            }
         var print_div = document.getElementById("hidden_div_pengiriman");
var print_area = window.open();
print_area.document.write(print_div.innerHTML);
print_area.document.close();
print_area.focus();
print_area.print();
print_area.close();
        }
        }});

        $('#r_btncetakpengiriman').click(function(){
        var foo = "bar";
        if(foo=="bar"){
        var isgood = confirm('Apakah data lembar pengiriman benar ?');
        if(isgood){
          if($('#r_penerima').val()==''||$('#r_alamatpenerima').val()==''||$('#r_telfonpenerima').val()==''){
            alert('Maaf, Data Penerima Tidak Boleh Kosong !');
          }else{
            if($('#r_pengirim').val()!=''){
              $('#r_cetakpengirim').html($('#r_pengirim').val());
            }else{
              $('#r_cetakpengirim').html($('#username_asli').html());
            }
            if($('#r_telfonpengirim').val()!=''){
                $('#r_cetaktelppengirim').html($('#r_telfonpengirim').val());
            }else{
              $('#r_cetaktelppengirim').html($('#telp_asli').html());
            }
            if($('#r_alamatpengirim').val()!=''){
              $('#r_cetakalamatpengirim').html($('#r_alamatpengirim').val());
            }else{
              $('#r_cetakalamatpengirim').html($('#alamat_asli').html());
            }
            if($('#r_keterangan').val()!=''){
              $('#r_cetakketerangan').html('<hr> <b>Keterangan : </b>'+$('#r_keterangan').val());
            }else{
              $('#r_cetakketerangan').html('');
            }
            $('#r_cetakpenerima').html($('#r_penerima').val());
            $('#r_cetakalamatpenerima').html($('#r_alamatpenerima').val());
            $('#r_cetaktelppenerima').html($('#r_telfonpenerima').val());
            var print_div = document.getElementById("hidden_div_reseller");
            var print_area = window.open();
            print_area.document.write(print_div.innerHTML);
            print_area.document.close();
            print_area.focus();
            print_area.print();
            print_area.close();
          }
            
        }
        }});
        $('#btnbersih').click(function(){
            $('#penerima').val('');
            $('#telfonpenerima').val('');
            $('#alamat').val('');
        });
        $('#r_btnbersih').click(function(){
            $('#r_penerima').val('');
            $('#r_telfonpenerima').val('');
            $('#r_alamatpenerima').val('');
            $('#r_pengirim').val('');
            $('#r_telfonpengirim').val('');
            $('#r_alamatpengirim').val('');
            $('#r_keterangan').val('');
        });
        </script>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>