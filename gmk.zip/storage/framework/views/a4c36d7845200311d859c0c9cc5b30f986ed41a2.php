<?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('title',$webset->webName); ?>
<?php $__env->startSection('favicon'); ?>
<link rel="shortcut icon" type="image" href="<?php echo e(asset('img/setting/'.$webset->ico)); ?>">
<?php $__env->stopSection(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startSection('content'); ?>
<script type="text/javascript">
function isNumberKey(evt)
{
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
    return false;

    return true;
}
</script>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Tambah Data Warna</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                     <?php if(session('status')): ?>
                    <div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Isi Data Dibawah Ini Sesuai Perintah !
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <form action="<?php echo e(url('warna')); ?>" role="form" method="POST">
                                        <div class="form-group">
                                            <label>Kode Warna</label>
                                            <input type="text" class="form-control" placeholder="contoh : 01, 02 dll" name="kode" required>
                                        </div>

                                        <?php if($errors->has('kode')): ?>
                                        <div class="alert alert-danger">
                                        <?php echo e($errors->first('kode')); ?>

                                         </div>
                                        <?php endif; ?>


                                        <div class="form-group">
                                            <label>Label Warna</label>
                                            <input type="text" class="form-control" placeholder="contoh : merah, biru dll" name="label_warna" required>
                                            
                                        </div>
                                        <div class="form-group">
                                            <label>Hex</label>
                                            <input type="color" name="hex" value="#ff0000" required>
                                            <p class="help-block">*Minimal 8 karakter</p>
                                        </div>
                                        <?php echo e(csrf_field()); ?>

                                        <input class="btn btn-primary" type="submit" name="submit" value="simpan">
                                        <a onclick="window.history.go(-1);" class="btn btn-danger">Kembali</a>
                                    </form>
                                </div>
                              
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>