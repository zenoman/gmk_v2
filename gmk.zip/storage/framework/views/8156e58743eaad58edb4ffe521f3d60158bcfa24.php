<?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('title',$webset->webName); ?>
<?php $__env->startSection('favicon'); ?>
<link rel="shortcut icon" type="image" href="<?php echo e(asset('img/setting/'.$webset->ico)); ?>">
<?php $__env->stopSection(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startSection('css'); ?>
<!-- DataTables CSS -->
    <link href="<?php echo e(asset('assets/vendor/datatables-plugins/dataTables.bootstrap.css')); ?>" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="<?php echo e(asset('assets/vendor/datatables-responsive/dataTables.responsive.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Admin</h1>

                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">

                <div class="col-lg-12">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <a href="<?php echo e(url('admin/create')); ?>" class="btn btn-primary"><i class="fa fa-pencil"></i> Tambah Data</a>
                    <br><br>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            List Data Admin
                        </div>
                        <!-- /.panel-heading -->

                        <div class="panel-body">

                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Email</th>
                                        <th>No. Telfon</th>
                                        <th>Level</th>
                                        <th class="text-center">Aksi</th>
                                        <!--th>Level</th-->
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1;?>
                                    <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $no = $i++;?>
                                    <?php if(Session::get('iduser')!=$row->id): ?>
                                    <tr>
                                        <td><?php echo e($no); ?></td>
                                        <td><?php echo e($row->nama); ?></td>
                                        <td><?php echo e($row->email); ?></td>
                                        <td><?php echo e($row->telp); ?></td>
                                        <td><?php echo e($row->level); ?></td>
                                        <td class="text-center">
                                        	
                                        <?php if(Session::get('level') == 'super_admin'): ?>
                                            <?php if($row->level=='programer'): ?>
                                            -
                                        <?php else: ?>
                                        
                                        <a href="<?php echo e(url('admin/'.$row->id.'/changepass')); ?> " class="btn btn-warning btn-sm">
                                        <i class="fa fa-key"></i> Ganti Password</a>

                                        <a href="<?php echo e(url('admin/'.$row->id)); ?>" class="btn btn-success btn-sm">
                                        <i class="fa fa-wrench"></i> Edit</a>

                                        <a onclick="return confirm('Hapus Data ?')" href="<?php echo e(url('admin/'.$row->id.'/delete')); ?>" class="btn btn-danger btn-sm">
                                        <i class="fa fa-trash-o"></i> Hapus</a>                  <?php endif; ?>                      <?php else: ?>
                                        <a href="<?php echo e(url('admin/'.$row->id.'/changepass')); ?> " class="btn btn-warning btn-sm">
                                        <i class="fa fa-key"></i> Ganti Password</a>

                                        <a href="<?php echo e(url('admin/'.$row->id)); ?>" class="btn btn-success btn-sm">
                                        <i class="fa fa-wrench"></i> Edit</a>

                                        <a onclick="return confirm('Hapus Data ?')" href="<?php echo e(url('admin/'.$row->id.'/delete')); ?>" class="btn btn-danger btn-sm">
                                        <i class="fa fa-trash-o"></i> Hapus</a>
                                                     <?php endif; ?>
                                                     
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
        </div>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('js'); ?>
        <!-- DataTables JavaScript -->
        <script src="<?php echo e(asset('assets/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendor/datatables-plugins/dataTables.bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendor/datatables-responsive/dataTables.responsive.js')); ?>"></script>
        <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>