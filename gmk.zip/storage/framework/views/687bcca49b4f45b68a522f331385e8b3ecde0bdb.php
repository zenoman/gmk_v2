<?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('title',$webset->webName); ?>
<?php $__env->startSection('favicon'); ?>
<link rel="shortcut icon" type="image" href="<?php echo e(asset('img/setting/'.$webset->ico)); ?>">
<?php $__env->stopSection(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
           <div class="row">
           
                <br>
                 <?php if(session('statuslogin')): ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo e(session('statuslogin')); ?>

            </div>
            <?php endif; ?>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-shopping-cart fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo e($jumlahtransaksi); ?></div>
                                    <div>Transaksi bulan ini</div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-users fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">
                                    <?php echo e($jumlahuser); ?>

                                    </div>
                                    <div>Pengguna</div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-cube fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">
                                        <?php echo e($jumlahstok); ?>

                                    </div>
                                    <div>Total Stok Barang</div>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
                 <div class="col-lg-3 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-support fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo e($jumlahtransaksig); ?></div>
                                    <div>Transaksi gagal</div>
                                </div>
                            </div>
                        </div>
                     </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Penjualan Minggu Ini
                           
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div id="morris-area-chart"></div>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>
                
                <!-- <div class="col-lg-4">
                <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i>Kategori Terlaris Minggu Ini
                        </div>
                        <div class="panel-body">
                            <div id="morris-donut-chart"></div>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('js'); ?>
        <!-- Morris Charts JavaScript -->
    <script src="<?php echo e(asset('assets/vendor/raphael/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/morrisjs/morris.min.js')); ?>"></script>
    <!--script src="<?php echo e(asset('assets/data/morris-data.js')); ?>"></script-->
    <?php
        $date = date('Y-m-d');
        $waktu = strtotime($date);
        
        $minus7 = strtotime("-7 days", $waktu);
        $hasil7 = date('Y-m-d',$minus7);
        $jumlah7 = DB::table('tb_transaksis')->where('tgl',$hasil7)->count();

        $minus6 = strtotime("-6 days", $waktu);
        $hasil6 = date('Y-m-d',$minus6);
        $jumlah6 = DB::table('tb_transaksis')->where('tgl',$hasil6)->count();

        $minus5 = strtotime("-5 days", $waktu);
        $hasil5 = date('Y-m-d',$minus5);
        $jumlah5 = DB::table('tb_transaksis')->where('tgl',$hasil5)->count();

        $minus4 = strtotime("-4 days", $waktu);
        $hasil4 = date('Y-m-d',$minus4);
        $jumlah4 = DB::table('tb_transaksis')->where('tgl',$hasil4)->count();

        $minus3 = strtotime("-3 days", $waktu);
        $hasil3 = date('Y-m-d',$minus3);
        $jumlah3 = DB::table('tb_transaksis')->where('tgl',$hasil3)->count();

        $minus2 = strtotime("-2 days", $waktu);
        $hasil2 = date('Y-m-d',$minus2);
        $jumlah2 = DB::table('tb_transaksis')->where('tgl',$hasil2)->count();

        $minus1 = strtotime("-1 days", $waktu);
        $hasil1 = date('Y-m-d',$minus1);
        $jumlah1 = DB::table('tb_transaksis')->where('tgl',$hasil1)->count();

        $jumlah = DB::table('tb_transaksis')->where('tgl',$date)->count(); 
    ?>
                
    <script type="text/javascript">
        $(function() {

    Morris.Area({
        parseTime:false,
        element: 'morris-area-chart',
        data: [{
            period: '<?php echo e($hasil7); ?>',
            itouch: <?php echo e($jumlah7); ?>

        }, {
            period: '<?php echo e($hasil6); ?>',
            itouch: <?php echo e($jumlah6); ?>

        }, {
            period: '<?php echo e($hasil5); ?>',
            itouch: <?php echo e($jumlah5); ?>

        }, {
            period: '<?php echo e($hasil4); ?>',
            itouch: <?php echo e($jumlah4); ?>

        }, {
            period: '<?php echo e($hasil3); ?>',
            itouch: <?php echo e($jumlah3); ?>

        }, {
            period: '<?php echo e($hasil2); ?>',
            itouch: <?php echo e($jumlah2); ?>

        }, {
            period: '<?php echo e($hasil1); ?>',
            itouch: <?php echo e($jumlah1); ?>

        }, {
            period: '<?php echo e($date); ?>',
            itouch: <?php echo e($jumlah); ?>

        }],
        xkey: ['period'],
        ykeys: ['itouch'],
        labels: ['Jumlah'],
        pointSize: 2,
        hideHover: 'auto',
        resize: true
    });

    
    
});
    </script>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>