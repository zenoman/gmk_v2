    <?php $__env->startSection('header'); ?>
    <?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <title><?php echo e($webset->webName); ?></title>
    <link rel="shortcut icon" type="image" href="<?php echo e(asset('img/setting/'.$webset->ico)); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
   
    <?php $__env->startSection('logo'); ?>
    <?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('img/setting/'.$webset->logo)); ?>" alt="" ></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container">
        <br>
        <?php $__currentLoopData = $kategorinama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2 class="new text-center">ARTIKEL BERKATEGORI "<?php echo e($kat->nama); ?>"</h2>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br>
        <div class="col-md-10">
            <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6">
            <div class="content-bottom">
                <div class="col-md-12 latter">
                    <img src="<?php echo e(asset('img/artikel/'.$art->gambar)); ?>" alt="" width="100%">
                    <br><br>
                    <h6><?php echo e($art->judul); ?></h6>
                    <br><br>
                    <p><?php echo substr($art->isi,0,200); ?></p>
                    <br>
                    <span class="label label-primary" style="background-color: #fa7455;">
                        <i class="fa fa-eye"></i> <?php echo e($art->dilihat); ?>

                    </span>&nbsp;
                    <span class="label label-primary" style="background-color: #fa7455;">
                        <i class="fa fa-calendar"></i> <?php echo e($art->tgl); ?>

                    </span>
                    &nbsp;
                    <span class="label label-primary" style="background-color: #fa7455;">
                        <i class="fa fa-tag"></i> <?php echo e($art->nama); ?>

                    </span>
                    <br>
                    <div class="text-center">
                        <a href="<?php echo e(url('/detail-artikel/'.$art->link)); ?>" class="btn btn-block tombol" style="color: white;">
                        Lanjut Baca
                    </a>
                    </div>
                    <div class="clearfix"> </div>
                </div>
         
                    <div class="clearfix"> </div>
            </div>
        </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
        <div class="col-md-2">
             <div class="single-bottom">
                        <h4>Kategori</h4>
                        <ul>
                             <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(url('list-artikel/'.$kategori->id.'/kategori')); ?>">
                                    <label for="brand"><span></span><?php echo e($kategori->nama); ?></label>
                                </a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </ul>
                    </div>
        </div>
        </div>
</div>
   <?php $__env->stopSection(); ?>
    
    
<?php echo $__env->make('layout/masteruser', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>