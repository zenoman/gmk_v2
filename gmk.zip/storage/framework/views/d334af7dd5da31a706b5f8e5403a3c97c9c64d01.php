<?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('title',$webset->webName); ?>
<?php $__env->startSection('favicon'); ?>
<link rel="shortcut icon" type="image" href="<?php echo e(asset('img/setting/'.$webset->ico)); ?>">
<?php $__env->stopSection(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startSection('content'); ?>
<script>
function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
    return false;

    return true;
}
</script>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Edit Data User</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <?php if(session('status')): ?>
                    <div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Edit Data Dibawah Ini Sesuai Perintah !
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                            <form action="/user/<?php echo e($datauser->id); ?>" role="form" enctype="multipart/form-data" method="POST">
                                        <!-- action="<?php echo e(url('myform/myform/')); ?>" -->
                                        <!-- action="<?php echo e(url('user/').$datauser->id); ?>" -->
                                        <div class="form-group">
                                            <label>Nama</label>
                                            <input type="text" class="form-control" name="nama" value="<?php echo e($datauser->nama); ?>" required>
                                        </div>
                                        <?php if($errors->has('nama')): ?>
                                        <div class="alert alert-danger">
                                        <?php echo e($errors->first('nama')); ?>

                                         </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                            <label>Username</label>
                                            <input type="text" class="form-control" name="username" value="<?php echo e($datauser->username); ?>" required>
                                        </div>
                                        <?php if($errors->has('username')): ?>
                                        <div class="alert alert-danger">
                                        <?php echo e($errors->first('username')); ?>

                                         </div>
                                        <?php endif; ?>
                                         <div class="form-group">
                                            <label>No. Telfon</label>
                                            <input type="text" class="form-control" value="<?php echo e($datauser->telp); ?>" name="no_telfon" onkeypress="return isNumberKey(event)" required>
                                        </div>
                                        <?php if($errors->has('no_telfon')): ?>
                                        <div class="alert alert-danger">
                                        <?php echo e($errors->first('no_telfon')); ?>

                                         </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="email" class="form-control" name="email" value="<?php echo e($datauser->email); ?>" required>
                                        </div>
                                       <?php if($errors->has('email')): ?>
                                        <div class="alert alert-danger">
                                            <?php echo e($errors->first('email')); ?>

                                         </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                        <label>Alamat</label>
                                        <textarea class="form-control" rows="3" name="alamat"><?php echo e($datauser->alamat); ?></textarea>
                                        </div>
                                        <?php if($errors->has('alamat')): ?>
                                       <div class="alert alert-danger">
                                        <?php echo e($errors->first('alamat')); ?>

                                         </div>
                                       <?php endif; ?>

                                        <div class="form-group">
                                            <label>Kota</label>
                                            <input type="text" class="form-control" placeholder="Contoh : Kediri" name="kota" value="<?php echo e($datauser->kota); ?>" required>
                                        </div>
                                          <?php if($errors->has('kota')): ?>
                                       <div class="alert alert-danger">
                                        <?php echo e($errors->first('kota')); ?>

                                         </div>
                                       <?php endif; ?>
                                        
                                        <div class="form-group">
                                            <label>Provinsi</label>
                                            <select class="form-control" name="provinsi">
                                           
                                       <option value="aceh" <?php if($datauser->provinsi=="aceh"): ?>selected <?php endif; ?>>Aceh</option>

                                        <option value="sumatera utara" <?php if($datauser->provinsi=="sumatera utara"): ?>selected <?php endif; ?>>Sumatera Utara</option>

                                        <option value="sumatera barat" <?php if($datauser->provinsi=="sumatera barat"): ?>selected <?php endif; ?>>Sumatera Barat</option>

                                        <option value="riau" <?php if($datauser->provinsi=="riau"): ?>selected <?php endif; ?>>Riau</option>

                                        <option value="kepuluan riau" <?php if($datauser->provinsi=="kepuluan riau"): ?>selected <?php endif; ?>>Kepulauan Riau</option>

                                        <option value="jambi" <?php if($datauser->provinsi=="jambi"): ?>selected <?php endif; ?>>Jambi</option>

                                        <option value="sumatera selatan" <?php if($datauser->provinsi=="sumatera selatan"): ?>selected <?php endif; ?>>Sumatera Selatan</option>

                                        <option value="bangka belitung" <?php if($datauser->provinsi=="bangka belitung"): ?>selected <?php endif; ?>>Bangka Belitung</option>

                                        <option value="bengkulu" <?php if($datauser->provinsi=="bengkulu"): ?>selected <?php endif; ?>>Bengkulu</option>

                                        <option value="lampung" <?php if($datauser->provinsi=="lampung"): ?>selected <?php endif; ?>>Lampung</option>

                                        <option value="jakarta" <?php if($datauser->provinsi=="jakarta"): ?>selected <?php endif; ?>>DKI Jakarta</option>

                                        <option value="jawa barat" <?php if($datauser->provinsi=="jawa barat"): ?>selected <?php endif; ?>>Jawa Barat</option>

                                        <option value="banten" <?php if($datauser->provinsi=="banten"): ?>selected <?php endif; ?>>Banten</option>

                                        <option value="jawa tengah" <?php if($datauser->provinsi=="jawa tengah"): ?>selected <?php endif; ?>>Jawa Tengah</option>

                                        <option value="yogyakarta" <?php if($datauser->provinsi=="yogyakarta"): ?>selected <?php endif; ?>>Yogyakarta</option>

                                        <option value="jawa timur" <?php if($datauser->provinsi=="jawa timur"): ?>selected <?php endif; ?>>Jawa Timur</option>

                                        <option value="bali" <?php if($datauser->provinsi=="bali"): ?>selected <?php endif; ?>>Bali</option>

                                        <option value="NTB" <?php if($datauser->provinsi=="NTB"): ?>selected <?php endif; ?>>NTB</option>

                                        <option value="NTT" <?php if($datauser->provinsi=="NTT"): ?>selected <?php endif; ?>>NTT</option>

                                        <option value="kalimantan utara" <?php if($datauser->provinsi=="kalimantan utara"): ?>selected <?php endif; ?>>Kalimantan Utara</option>

                                        <option value="kalimantan barat" <?php if($datauser->provinsi=="kalimantan barat"): ?>selected <?php endif; ?>>Kalimantan Barat</option>

                                        <option value="kalimantan tengah" <?php if($datauser->provinsi=="kalimantan tengah"): ?>selected <?php endif; ?>>Kalimantan Tengah</option>

                                        <option value="kalimantan selatan" <?php if($datauser->provinsi=="kalimantan selatan"): ?>selected <?php endif; ?>>Kalimantan Selatan</option>

                                        <option value="kalimantan timur" <?php if($datauser->provinsi=="kalimantan timur"): ?>selected <?php endif; ?>>Kalimantan Timur</option>

                                        <option value="sulawesi utara" <?php if($datauser->provinsi=="sulawesi utara"): ?>selected <?php endif; ?>>Sulawesi Utara</option>

                                        <option value="sulawesi barat" <?php if($datauser->provinsi=="sulawesi barat"): ?>selected <?php endif; ?>>Sulawesi Barat</option>

                                        <option value="sulawesi tengah" <?php if($datauser->provinsi=="sulawesi tengah"): ?>selected <?php endif; ?>>Sulawesi Tengah</option>

                                        <option value="sulawesi tenggara" <?php if($datauser->provinsi=="sulawesi tenggara"): ?>selected <?php endif; ?>>Sulawesi Tenggara</option>

                                        <option value="sulawesi selatan" <?php if($datauser->provinsi=="sulawesi selatan"): ?>selected <?php endif; ?>>Sulawesi Selatan</option>

                                        <option value="gorontalo" <?php if($datauser->provinsi=="gorontalo"): ?>selected <?php endif; ?>>Gorontalo</option>

                                        <option value="maluku"  <?php if($datauser->provinsi=="maluku"): ?>selected <?php endif; ?>>Maluku</option>

                                        <option value="maluku utara" <?php if($datauser->provinsi=="maluku utara"): ?>selected <?php endif; ?>>Maluku Utara</option>

                                        <option value="papua barat" <?php if($datauser->provinsi=="papua barat"): ?>selected <?php endif; ?>>Papua Barat</option>

                                        <option value="papua" <?php if($datauser->provinsi=="papua"): ?>selected <?php endif; ?>>Papua</option>
                                            </select>
                                        
                                        </div>

                                        <div class="form-group">
                                            <label>Kode Pos</label>
                                            <input type="text" class="form-control" placeholder="Contoh : 06" name="kode_pos" value="<?php echo e($datauser->kodepos); ?>" required onkeypress="return isNumberKey(event)">
                                        </div>
                                        <?php if($errors->has('kode_pos')): ?>
                                       <div class="alert alert-danger">
                                        <?php echo e($errors->first('kode_pos')); ?>

                                         </div>
                                       <?php endif; ?>
                                        <div class="form-group">
                                            <label>Level</label>
                                            <select name="level" class="form-control">
                                                <option <?php if($datauser->level=='biasa'): ?> selected <?php endif; ?> value="biasa">Penguna Biasa</option>
                                                <option <?php if($datauser->level=='reseller'): ?> selected <?php endif; ?> value="reseller">Reseller</option>
                                            </select>
                                        </div>
                                       <div class="form-group">
                                            <label>Ganti Gambar</label>
                                            <p>
                                            <?php if($datauser->ktp_gmb!=''): ?>
                                            <img src="../img/user/<?php echo e($datauser->ktp_gmb); ?>" width="100">
                                            <?php endif; ?>
                                            <p>
                                            <input type="file" name="gambar_ktp" accept="image/*">
                                        </div>
                                          <?php if($errors->has('gambar_ktp')): ?>
                                       <div class="alert alert-danger">
                                        <?php echo e($errors->first('gambar_ktp')); ?>

                                         </div>
                                       <?php endif; ?>
                                        <?php echo e(csrf_field()); ?>

                                        
                                        <input type="hidden" name="_method" value="PUT">
                                        <input class="btn btn-primary" type="submit" name="submit" value="simpan">
                                        <a onclick="window.history.go(-1);" class="btn btn-danger">Kembali</a>
                                    </form>
                                </div>
                              
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>