    
    <?php $__env->startSection('header'); ?>
    <?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <title><?php echo e($webset->webName); ?></title>
    <link rel="shortcut icon" type="image" href="<?php echo e(asset('img/setting/'.$webset->ico)); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
     <?php $__env->startSection('logo'); ?>
    <?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('img/setting/'.$webset->logo)); ?>" alt="" style="width:70%;"></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
   <div class="container">
        <div class="product">
        <h2 class="new text-center">SEMUA PRODUK</h2>
        <div class="col-md-10">
           <div class="pink">
               <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 box-in-at">
            <div class=" grid_box portfolio-wrapper">       
                             <a> 
                                 <?php
                        $fotos = DB::table('gambar')
                        ->where('kode_barang',$barang->kode_barang)
                        ->limit(1)
                        ->get();
                        ?>
                        <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset('img/barang/'.$foto->nama)); ?>" class="img-responsive" style="width:70%;" alt="">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="zoom-icon">
                                    <ul class="in-by" style="padding-bottom: 5px;">
                                        <li><h5><?php echo e($barang->barang); ?> - <?php echo e($barang->total); ?> Pcs</h5></li>
                                    </ul>
                                    <ul class="in-by">
                                        <li><h5>Ukuran :</h5></li>
                                        <?php
                                        $detail = DB::table('tb_barangs')
                                        ->where('kode',$barang->kode_barang)
                                        ->get();
                                        ?>
                                        <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                   
                                        <li><span><?php echo e($dtl->warna); ?></span></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                    
                    
                        <ul class="in-by-color">
                            <li><h5>Warna :</h5></li>   
                            <?php
                                        $detail = DB::table('tb_barangs')
                                        ->select(DB::raw('tb_barangs.kode,tb_varian.hex'))
                                        ->leftjoin('tb_varian','tb_varian.kode_v','=','tb_barangs.kode_v')
                                        ->where('kode',$barang->kode_barang)
                                        ->get();
                                        ?>
                                        <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                   
                                        <li><span class="color" style="background-color: <?php echo e($dtl->hex); ?>;"> </span></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </ul>
                    
                        </div> </a>     
                   </div>
                        <div class="grid_1 simpleCart_shelfItem">
                            <a href="<?php echo e(url('/detailbarang/'.$barang->id)); ?>" class="cup item_add"><span class=" item_price" >
                                <?php if($barang->diskon > 0): ?>
                                <?php
                                $hargadiskon = $barang->harga_barang - ($barang->diskon/100*$barang->harga_barang); 
                                ?>
                                <?php echo e("Rp ". number_format($hargadiskon,0,',','.')); ?>

                            <?php else: ?>
                                <?php echo e("Rp ". number_format($barang->harga_barang,0,',','.')); ?>

                            <?php endif; ?>
                            </span></a>                  
                        </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="clearfix"> </div>
                <div class="col-md-12 text-center">
                <?php echo e($barangs->links()); ?>

                <br>
                <button class="tombol" onclick="history.go(-1)"> <i class="fa fa-arrow-left"></i> Kembali</button>
            </div>
                <div class="clearfix"> </div>
        </div> 
        </div>
        <div class="col-md-2">
            <div class="single-bottom">
                        <h4>Cari Produk</h4>
                        <br>
                        <form action="">
                            <div class="form-group text-center">
                                <input type="text" class="form-control" required>
                                 <button class="tombol"><i class="fa fa-search"></i> Cari</button>
                            </div>
                        </form>
                    </div>
            <div class="single-bottom">
                        <h4>Kategori</h4>
                        <ul>
                             <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(url('/semuaproduk/'.$kategori->id.'/kategori')); ?>">
                                    <label for="brand"><span></span><?php echo e($kategori->kategori); ?></label>
                                </a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </ul>
                    </div>
        </div>
        </div>
        <!----> 
</div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/masteruser', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>