<?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('title',$webset->webName); ?>
<?php $__env->startSection('favicon'); ?>
<link rel="shortcut icon" type="image" href="<?php echo e(asset('img/setting/'.$webset->ico)); ?>">
<?php $__env->stopSection(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/vendor/datatables-plugins/dataTables.bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/datatables-responsive/dataTables.responsive.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Laporan Pengeluaran Bulan <?php echo e($bulan); ?> Tahun <?php echo e($tahun); ?> </h1>

                </div>
            </div>
            <div class="row">

                <div class="col-lg-12">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <a href="<?php echo e(url('/cetakpengeluaran/'.$bulan.'/'.$tahun)); ?>" class="btn btn-primary" target="_blank()"><i class="fa fa-print"></i> Print</a>

                    <a href="<?php echo e(url('/exsportpengeluaran/'.$bulan.'/'.$tahun)); ?>" class="btn btn-success"><i class="fa fa-file-excel-o"></i> Exsport Excel</a>
                    <br><br>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            List Data Pengeluaran
                        </div>

                        <div class="panel-body">

                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>tanggal</th>
                                        <th>Kode</th>
                                        <th>Barang</th>
                                        <th>Warna</th>
                                        <th>Jumlah</th>
                                        <th>Harga</th>
                                        <th>Total</th>
                                        <th>Pembuat</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $i=1;
                                    ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                      <td><?php echo e($i++); ?></td>
                                      <td><?php echo e($row->tgl); ?></td>
                                      <td><?php echo e($row->kode_barang); ?></td>
                                      <td><?php echo e($row->barang_jenis); ?></td>
                                      <td><?php echo e($row->varian); ?></td>
                                      <td><?php echo e($row->jumlah); ?> Pcs</td>
                                      <td>
                                        <?php echo e("Rp ".number_format($row->harga_beli,0,',','.')); ?>

                                        </td>
                                      <td>
                                           <?php echo e("Rp ".number_format($row->total,0,',','.')); ?>

                                      </td>
                                      <td><?php echo e($row->username); ?></td>
                                  </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo e($data->links()); ?>

                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
        </div>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('js'); ?>
        <!-- DataTables JavaScript -->
        <script src="<?php echo e(asset('assets/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendor/datatables-plugins/dataTables.bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendor/datatables-responsive/dataTables.responsive.js')); ?>"></script>
        <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true,
            'paging':false
        });
    });
    </script>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>