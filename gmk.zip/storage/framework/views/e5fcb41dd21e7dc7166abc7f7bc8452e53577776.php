    <?php $__env->startSection('header'); ?>
    <?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <title><?php echo e($webset->webName); ?></title>
    <link rel="shortcut icon" type="image" href="<?php echo e(asset('img/setting/'.$webset->ico)); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
   
    <?php $__env->startSection('logo'); ?>
    <?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('img/setting/'.$webset->logo)); ?>" alt="" style="width:70%;"></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container">
        <br>
        <h2 class="new text-center">CARA BELANJA</h2>
        <br>
        <div class="col-md-12">
            <?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $web): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="content-bottom">
                <div class="col-md-12 latter">
                    <div class="text-center">
                        <img src="<?php echo e(asset('img/web/carabelanja.jpg')); ?>" alt="" width="70%">    
                    </div>
                    
                    <br>
                    <div>
                        <div class="col-md-2">
                        </div>
                        <div class="col-md-8">
                            <p><?php echo $web->peraturan; ?></p>        
                        </div>
                        <div class="col-md-2">
                        </div>
                        
                    </div>
                    <br>
                    <div class="clearfix"> </div>
                </div>
         
                    <div class="clearfix"> </div>
            </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <br>
        </div>
        </div>
</div>
   <?php $__env->stopSection(); ?>
    
    
<?php echo $__env->make('layout/masteruser', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>