<?php if(!Session::get('username')): ?>
<script type="text/javascript">
    window.location.href = '<?php echo e(url("/validatelogin")); ?>';
</script>
<?php endif; ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>
        <?php echo $__env->yieldContent('title'); ?>
    </title>
    <?php echo $__env->yieldContent('favicon'); ?>
    
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo e(asset('assets/vendor/metisMenu/metisMenu.min.css')); ?>" rel="stylesheet">
        <?php echo $__env->yieldContent('css'); ?>
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('assets/dist/css/sb-admin-2.css')); ?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo e(asset('assets/vendor/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
    <!-- Vue Js -->
   <!--  <script src="<?php echo e(asset('js/app.js')); ?>" defer></script> -->
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo e(url('/dashboard')); ?>">Welcome <?php echo e(Session::get('level')); ?> <?php echo e(Session::get('username')); ?></a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-bell fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-alerts" id="barnotiv">
                    	</ul>
                	</li>
                
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="<?php echo e(url('/admin/'.Session::get('iduser'))); ?>"><i class="fa fa-user fa-fw"></i> Edit Profile</a>
                        </li>
                        
                        <li class="divider"></li>
                        <li><a href="<?php echo e(url('/admin/'.Session::get('iduser').'/changepass')); ?>"><i class="fa fa-key fa-fw"></i> Edit Password</a>
                        </li>
                        
                        <li class="divider"></li>
                        <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                </li>
            </ul>

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="<?php echo e(url('/dashboard')); ?>"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-users fa-fw"></i> Pengguna<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level collapse">
                                <?php if(Session::get('level') != 'admin'): ?>
                                <li>
                                    <a href="<?php echo e(url('/admin')); ?>"> Admin
                                    </a>
                                </li>
                                <?php endif; ?>
                                <li>
                                    <a href="<?php echo e(url('/user')); ?>">
                                    User</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="<?php echo e(url('/kategori')); ?>"><i class="fa fa-th-large fa-fw"></i> Kategori</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/warna')); ?>"><i class="fa fa-tint fa-fw"></i> Warna</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/barang')); ?>"><i class="fa fa-cube fa-fw"></i> Barang</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-money fa-fw"></i> Transaksi<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level collapse">
                                <li>
                                     <a href="<?php echo e(url('/pembelian')); ?>"> Pembelian</a>
                                </li>
                                <li>
                                     <a href="<?php echo e(url('/pembelianlain')); ?>"> Pembelian Lain</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/pengeluaran')); ?>">Pengeluaran</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/transaksilangsung')); ?>">Transaksi Langsung</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/listtransaksilangsung')); ?>">List Transaksi Langsung</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/pembelian/gagal')); ?>">Transaksi Gagal</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/pembelian/listcancel')); ?>">List Cancel</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="<?php echo e(url('/slider')); ?>"><i class="fa fa-image fa-fw"></i> Slider</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-file-text fa-fw"></i> Artikel<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level collapse">
                                <li>
                                    <a href="<?php echo e(url('/kategori-artikel')); ?>"> Kategori
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/artikel')); ?>">
                                    Artikel</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="<?php echo e(url('bank')); ?>"><i class="fa fa-credit-card"></i> Rekening Toko</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/setting')); ?>"><i class="fa fa-gear fa-fw"></i> Setting</a>
                        </li>
                        <?php if(Session::get('level') != 'admin'): ?>
                                <li>
                        <li>
                            <a href="<?php echo e(url('/backup')); ?>"><i class="fa fa-download fa-fw"></i> Backup Data</a>
                        </li>
                        <?php endif; ?>
                        <?php if(Session::get('level') != 'admin'): ?>
                       <li>
                            <a href="#"><i class="fa fa-file fa-fw"></i> Laporan<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level collapse">
                                <li>
                                    <a href="<?php echo e(url('/laporan/pengeluaran')); ?>">Laporan Pengeluaran</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/laporan/pemasukan')); ?>">Laporan Pemasukan</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/laporan/detailpemasukan')); ?>">Laporan Detail Pemasukan</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/laporan/pemasukanlain')); ?>">Laporan Pemasukan Lain</a>
                                </li>
                                <!-- <li>
                                    <a href="<?php echo e(url('/laporan/transaksilangsung')); ?>">Laporan Transaksi Langsung</a>
                                </li> -->
                                <!-- <li>
                                    <a href="<?php echo e(url('/laporan/detailtransaksilangsung')); ?> ">Laporan Detail Transaksi Langsung</a>
                                </li> -->
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        
                         <li>
                            <a href="<?php echo e(url('/omset')); ?>"><i class="fa fa-bar-chart-o fa-fw"></i> Omset</a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
        <div id="app">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    <audio src="<?php echo e(asset('files/notif.mp3')); ?>" type="audio/mpeg" id="notif"></audio>
    </div>
    <!-- /#wrapper -->
    
    <!-- jQuery -->
    <script src="<?php echo e(asset('assets/vendor/jquery/jquery.min.js')); ?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo e(asset('assets/vendor/metisMenu/metisMenu.min.js')); ?>"></script>

    
    <!-- Custom Theme JavaScript -->

    <script src="<?php echo e(asset('assets/js/bootstrap-notify.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/bootstrap-notify.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/js/sb-admin-2.js')); ?>"></script>
    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    
    <?php echo $__env->yieldContent('js'); ?>
    
    <script src="<?php echo e(asset('assets/js/notifikasi.js')); ?>"></script>
</body>

</html>