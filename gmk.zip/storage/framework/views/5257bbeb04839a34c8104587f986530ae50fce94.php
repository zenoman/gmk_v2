<?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('title',$webset->webName); ?>
<?php $__env->startSection('favicon'); ?>
<link rel="shortcut icon" type="image" href="<?php echo e(asset('img/setting/'.$webset->ico)); ?>">
<?php $__env->stopSection(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startSection('content'); ?>
<script type="text/javascript">
     function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
</script>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Tambah Data Barang</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Isi Data Dibawah Ini Sesuai Perintah !
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <?php if(count($errors) > 0): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
                                <div class="col-lg-12">
                                    <form action="/barang" role="form" method="POST" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label>Kode Barang</label>
                                            <input type="text" class="form-control" name="kode_barang" value="<?php echo e($kode); ?>" readonly>
                                        </div>

                                        <?php if($errors->has('kode_barang')): ?>
                                        <div class="alert alert-danger">
                                        <?php echo e($errors->first('kode_barang')); ?>

                                         </div>
                                        <?php endif; ?>


                                        <div class="form-group">
                                            <label>Nama Barang</label>
                                            <input type="text" class="form-control" name="nama_barang" value="<?php echo e(old('nama_barang')); ?>" required>
                                        </div>
                                        <?php if($errors->has('nama_barang')): ?>
                                        <div class="alert alert-danger">
                                        <?php echo e($errors->first('nama_barang')); ?>

                                         </div>
                                        <?php endif; ?>
                                        <div class="form-group">
                                        <label>Kategori</label>
                                        <select class="form-control" name="kategori">
                                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kat->id); ?>-<?php echo e($kat->kategori); ?>"><?php echo e($kat->kategori); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                               
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Deskripsi Barang</label>
                                            <textarea class="form-control" name="deskripsi" id="editor" rows="5"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label>Foto</label>
                                            <input type="file" class="form-control" name="photo[]" multiple required accept="image/*" id="photo">
                                            <p class="help-block">*Foto Tidak Lebih Dari 4 File dan berukuran kurang dari 3Mb</p> 
                                        </div>
                                         <?php if(session('errorfoto')): ?>
                            <div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo e(session('errorfoto')); ?>

                    </div>
                    <?php endif; ?>      <label>Harga Jual Barang</label>
                                        <div class="form-group input-group">
                                            
                                            <span class="input-group-addon">Rp.</span>
                                            <input type="text" onkeypress="return isNumberKey(event)" class="form-control" name="harga_barang" value="<?php echo e(old('harga_barang')); ?>" required>

                                        </div>

                                        <?php if($errors->has('harga_barang')): ?>
                                        <div class="alert alert-danger">
                                        <?php echo e($errors->first('harga_barang')); ?>

                                         </div>
                                        <?php endif; ?>

                                         <label>Harga Jual Barang Reseller</label>
                                        <div class="form-group input-group">
                                        <span class="input-group-addon">Rp. </span>
                                        <input type="text" onkeypress="return isNumberKey(event)" class="form-control" name="harga_reseller" value="<?php echo e(old('harga_reseller')); ?>" required>
                                        </div>
                                        
                                        <?php if(Session::get('level')!='admin'): ?>
                                        
                                        
                                        <label>Harga Beli Barang</label>
                                        <div class="form-group input-group">
                                            
                                            <span class="input-group-addon">Rp.</span>
                                            <input type="text" onkeypress="return isNumberKey(event)" class="form-control" name="harga_beli" value="<?php echo e(old('harga_beli')); ?>" required>

                                        </div>
                                        <?php else: ?>
                                        <input type="hidden" name="harga_beli" value="0" required>
                                        <?php endif; ?>
                                        <label>Diskon Barang</label>
                                        <div class="form-group input-group">
                                            
                                            <input type="number" min="0" max="99" onkeypress="return isNumberKey(event)" class="form-control" name="diskon_barang" value="0" required>
                                            <span class="input-group-addon">%</span>
                                        </div>
                                        
                                        <?php if($errors->has('diskon_barang')): ?>
                                        <div class="alert alert-danger">
                                        <?php echo e($errors->first('diskon_barang')); ?>

                                         </div>
                                        <?php endif; ?>
                                        
                                        <hr>
                                       <div id="newlink">
                                        <div class="row">
                                        <div class="col-md-4 form-group">
                                        <label>Ukuran</label>
                                        <input type="text" name="warna[]" value="" class="form-control" required>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                        <label>Warna</label>
                                        <select class="form-control" name="variasi[]">
                                                <?php $__currentLoopData = $warna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $war): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($war->kode_v); ?>"><?php echo e($war->kode_v); ?>-<?php echo e($war->varian); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                               
                                        </div>
                                        </div>
                                        <div class="col-md-4 form-group">
                                        <label>Stok</label>
                                        <input type="text" onkeypress="return isNumberKey(event)" name="stok[]" value="" class="form-control" required>

                                        </div>
                                        </div>
                                         </div>


                                        <?php echo e(csrf_field()); ?>

                                        <div id="addnew">
                                            <br>
                                            <div>
                                        <a href="javascript:new_link()" class="btn btn-success"><i class="fa fa-plus"></i> Tambah Variasi</a>
                                    </div>
                                        </div>

                                        <br>
                                        <hr>
                                        <input class="btn btn-primary" type="submit" name="submit" value="simpan">
                                        
                                        <a onclick="window.history.go(-1);" class="btn btn-danger">Kembali</a>
                                    </form>
                                </div>
                              
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
        <div id="newlinktpl" style="display:none" class="form-group">
            <hr>
             <div class="row">
                <div class="col-md-4 form-group">
                    <label>Ukuran</label>
                    <input type="text" name="warna[]" value="" class="form-control" required>
                </div>
            <div class="col-md-4">
                <div class="form-group">
                        <label>Warna</label>
                        <select class="form-control" name="variasi[]">
                        <?php $__currentLoopData = $warna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $war): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($war->kode_v); ?>"><?php echo e($war->kode_v); ?>-<?php echo e($war->varian); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                </div>
            </div>
                                        <div class="col-md-4 form-group">
                                        <label>Stok</label>
                                        <input type="text" onkeypress="return isNumberKey(event)" name="stok[]" value="" class="form-control" required>
                                        </div>
                                        </div>
        </div>
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('js'); ?>
         <script src="<?php echo e(asset('assets/js/ckeditor.js')); ?>"></script>
        <script type="text/javascript">
         
var ct = 1;
function new_link()
{
    ct++;
    var div1 = document.createElement('div');
    div1.id = ct;
    // link to delete extended form elements
    var delLink = '<a href="javascript:delIt('+ ct +')" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus Variasi</a><br>';
    div1.innerHTML = document.getElementById('newlinktpl').innerHTML + delLink;
    document.getElementById('newlink').appendChild(div1);
}
// function to delete the newly added set of elements
function delIt(eleId)
{
    d = document;
    var ele = d.getElementById(eleId);
    var parentEle = d.getElementById('newlink');
    parentEle.removeChild(ele);
}
function validate(frm)
{
    var ele = frm.elements['feedurl[]'];
    if (! ele.length)
    {
        alert(ele.value);
    }
    for(var i=0; i<ele.length; i++)
    {
        alert(ele[i].value);
    }
    return true;
}
function add_feed()
{
    var div1 = document.createElement('div');
    div1.innerHTML = document.getElementById('newlinktpl').innerHTML;
    document.getElementById('newlink').appendChild(div1);
}

</script>
<script>
      ClassicEditor
    .create( document.querySelector( '#editor' ), {
        toolbar: [ 'heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote' ],
        heading: {
            options: [
                { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
                { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
                { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' }
            ]
        }
    } )
    .catch( error => {
        console.log( error );
    } );
    $('input[type="file"]').change(function(){
    var imageSizeArr = 0;
    var imageSize = document.getElementById('photo');
    var imageCount = imageSize.files.length;
    var jumlah = 0;
    for (var i = 0; i < imageSize.files.length; i++)
    {
        jumlah +=1;
         var imageSiz = imageSize.files[i].size;
         var imagename = imageSize.files[i].name;
         if (imageSiz > 3000000) {
             $('#test').text('3');
             var imageSizeArr = 1;
         }
         if (imageSizeArr == 1)
         {
             alert('Maaf, gambar "'+imagename+'" terlalu besar / memiliki ukuran lebih dari 3MB');
             $('#photo').val('');
         }
     }
     if (jumlah > 4){
        alert('Maaf, gambar lebih dari 4 file');
             $('#photo').val('');
     }
 }); 
    </script>
        <?php $__env->stopSection(); ?>




<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>