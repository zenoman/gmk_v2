<?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('title',$webset->webName); ?>
<?php $__env->startSection('favicon'); ?>
<link rel="shortcut icon" type="image" href="<?php echo e(asset('img/setting/'.$webset->ico)); ?>">
<?php $__env->stopSection(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startSection('css'); ?>
<!-- DataTables CSS -->
    <link href="<?php echo e(asset('assets/vendor/datatables-plugins/dataTables.bootstrap.css')); ?>" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="<?php echo e(asset('assets/vendor/datatables-responsive/dataTables.responsive.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">User</h1>

                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">

                <div class="col-lg-12">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <a href="<?php echo e(url('user/create')); ?>" class="btn btn-primary"><i class="fa fa-pencil"></i> Tambah Data</a>
                    <button class="btn btn-info" data-toggle="modal" data-target="#searchModal">
                                        <i class="fa fa-search"></i> Cari Data</button>
                                <div class="modal fade" id="searchModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title" id="myModalLabel">Cari Data Spesifik Dari Semua Data</h4>
                                        </div>
                                        

                                        <div class="modal-body">
                                           <form method="post" action="<?php echo e(url('user/cari')); ?>">
                                            <div class="form-group">
                                                <input type="text" name="cari" class="form-control" placeholder="cari berdasarkan nama/usrname/email/kota user" required>
                                            </div>
                                           <?php echo e(csrf_field()); ?>

                                            <input type="submit" class="btn btn-info" value="Cari Data">
                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                            
                                            </form>
                                        </div>
                                 
                                    </div>
                                    <!-- /.modal-content -->
                                </div>
                                <!-- /.modal-dialog -->
                            </div>
                            <!-- /.modal -->
                    <br><br>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            List Data User
                        </div>
                        <!-- /.panel-heading -->

                        <div class="panel-body">

                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Username</th>
                                        <th>Nama</th>
                                        <th>Email</th>
                                        <th>Kota</th>
                                        <th>No. Telfon</th>
                                        <th class="text-center">Status</th>
										<th class="text-center">Aksi</th>
                                        <!--th>Level</th-->
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1;?>
                                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $no = $i++;?>
                                    <tr>
                                        <td class="text-center"><?php echo e($no); ?></td>
                                       <td>
                                        <?php if($row->level=='reseller'): ?>
                                        <span class="label label-primary"><?php echo e($row->username); ?>

                                        </span>
                                        <?php else: ?>
                                        <?php echo e($row->username); ?>

                                        <?php endif; ?>
                                        </td>
                                        <td><?php echo e($row->nama); ?></td>
                                        <td><?php echo e($row->email); ?></td>
                                        <td><?php echo e($row->kota); ?></td>
                                        <td><?php echo e($row->telp); ?></td>
                                        <td class="text-center">
                                            <?php if($row->cancel < 3): ?>
                                            <span class="label label-success">Aktif</span>
                                            <?php else: ?>
                                            <span class="label label-danger">Banned</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center tooltip-demo">
                                            <?php if($row->cancel < 3): ?>
                                            <a href="<?php echo e(url('user/'.$row->id.'/banned')); ?>" class="btn btn-primary btn-sm" onclick="return confirm('Banned User ?')">
                                           <i class="fa fa-lock"></i>
                                            </a> 
                                            <?php else: ?>
                                            <a href="<?php echo e(url('user/'.$row->id.'/unbanned')); ?>" class="btn btn-primary btn-sm" onclick="return confirm('Aktifkan User Kembali ?')">
                                           <i class="fa fa-unlock"></i>
                                            </a> 
                                            <?php endif; ?>
                                        

                                        <a href="<?php echo e(url('user/'.$row->id.'/changepass')); ?>" class="btn btn-warning btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Ganti Password">
                                            <i class="fa fa-key"></i>
                                        </a>
                                        <a href="<?php echo e(url('user/'.$row->id)); ?>" class="btn btn-success btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit data">
                                        <i class="fa fa-wrench"></i></a>

                                        <a onclick="return confirm('Hapus Data ?')" href="<?php echo e(url('user/'.$row->id.'/delete')); ?>" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Hapus Data">
                                        <i class="fa fa-trash-o"></i></a>                                        
                                        </td>
                                    </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo e($user->links()); ?>

                        </div>  
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
        </div>

        <?php $__env->stopSection(); ?>

         <?php $__env->startSection('js'); ?>
        <!-- DataTables JavaScript -->
        <script src="<?php echo e(asset('assets/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendor/datatables-plugins/dataTables.bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendor/datatables-responsive/dataTables.responsive.js')); ?>"></script>
        <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true,
            "paging":false
        });
    });
  
    </script>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>