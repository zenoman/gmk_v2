<?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('title',$webset->webName); ?>
<?php $__env->startSection('favicon'); ?>
<link rel="shortcut icon" type="image" href="<?php echo e(asset('img/setting/'.$webset->ico)); ?>">
<?php $__env->stopSection(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startSection('content'); ?>
<script type="text/javascript">
     function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
</script>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Edit Data Admin</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                      <?php if(session('status')): ?>
                    <div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Edit Data Dibawah Ini Sesuai Perintah !
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <form action="<?php echo e(url('/admin/'.$dataadmin->id)); ?>" role="form" method="POST">
                                        <div class="form-group">
                                            <label>Nama</label>
                                            <input type="text" class="form-control" name="nama" value="<?php echo e($dataadmin->nama); ?>" required>
                                        </div>
                                        <?php if($errors->has('nama')): ?>
                                        <div class="alert alert-danger">
                                        <?php echo e($errors->first('nama')); ?>

                                         </div>
                                        <?php endif; ?>
                                        <div class="form-group">
                                            <label>Username</label>
                                            <input type="text" class="form-control" value="<?php echo e($dataadmin->username); ?>" name="username" required pattern=".{8,}">
                                            <input type="hidden" value="<?php echo e($dataadmin->username); ?>" name="oldusername">
                                            <p class="help-block">*Minimal 8 karakter</p>
                                        </div>
                                        <?php if($errors->has('username')): ?>
                                        <div class="alert alert-danger">
                                        <?php echo e($errors->first('username')); ?>

                                         </div>
                                        <?php endif; ?>

                                        
                                        <div class="form-group">
                                            <label>No. Telfon</label>
                                            <input type="text" class="form-control" value="<?php echo e($dataadmin->telp); ?>" name="no_telfon" onkeypress="return isNumberKey(event)" required>
                                        </div>
                                        <?php if($errors->has('no_telfon')): ?>
                                        <div class="alert alert-danger">
                                        <?php echo e($errors->first('no_telfon')); ?>

                                         </div>
                                        <?php endif; ?>

                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="email" class="form-control" name="email" value="<?php echo e($dataadmin->email); ?>" required>
                                        </div>
                                       <?php if($errors->has('email')): ?>
                                        <div class="alert alert-danger">
                                        <?php echo e($errors->first('email')); ?>

                                         </div>
                                        <?php endif; ?>
                                        <div class="form-grop">
                                            <label>Level</label>
                                            <select class="form-control" name="level">
                                                <option value="admin" <?php if($dataadmin->level=="admin"): ?>selected <?php endif; ?>>admin</option>
                                                <option value="super_admin" <?php if($dataadmin->level=="super_admin"): ?>selected <?php endif; ?> >super admin</option>
                                                <option value="programer" <?php if($dataadmin->level=="programer"): ?>selected <?php endif; ?> >programer</option>
                                            </select>
                                        </div>
                                        <?php echo e(csrf_field()); ?>

                                        <br>
                                        <input type="hidden" name="_method" value="PUT">
                                        <input class="btn btn-primary" type="submit" name="submit" value="simpan">
                                        <a onclick="window.history.go(-1);" class="btn btn-danger">Kembali</a>
                                    </form>
                                </div>
                              
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>