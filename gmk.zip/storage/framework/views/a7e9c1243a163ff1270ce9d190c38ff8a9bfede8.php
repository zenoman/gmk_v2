    <?php $__env->startSection('header'); ?>
    <?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <title><?php echo e($webset->webName); ?></title>
    <link rel="shortcut icon" type="image" href="<?php echo e(asset('img/setting/'.$webset->ico)); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
   
    <?php $__env->startSection('logo'); ?>
    <?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('img/setting/'.$webset->logo)); ?>" alt="" style="width:70%;"></a>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('content'); ?>
<div class="banner">
<div class="container"> 
          <div class="wmuSlider example1">
               <div class="wmuSliderWrapper">
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sld): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <article style="position: absolute; width: 100%; opacity: 0;"> 
                    <div class="banner-wrap">
                    <div class="banner-top banner-bottom">
                         <a href="single.html">
                        <div class="banner-top-in at">
                            <img src="<?php echo e(asset('img/slider/'.$sld->foto)); ?>" class="img-responsive" alt="">

                        </div></a>
                        <div class="cart-at grid_1 simpleCart_shelfItem">
                                <!-- <div class="item_add"><span class="item_price" >123 $ <i> </i> </span></div> -->
                            <div class="off">
                                <label><?php echo e($sld->judul); ?></label>
                                <p><?php echo e($sld->deskripsi); ?></p>
                            </div>
                        </div>
                        <div class="clearfix"> </div>
                        
                        </div>
                        
                         <div class="clearfix"> </div>
                         
                     </div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <!---->
          <script src="<?php echo e(asset('user_aset/js/jquery.wmuSlider.js')); ?>"></script> 
              <script>
                $('.example1').wmuSlider({
                     pagination : false,
                     nav : false,
                     paginationControl:false,
                });         
             </script>  
        
        </div>   
    </div>
<div class="content">
    <div class="container">
        <div class="content-top">
        <h2 class="new text-center">KATEGORI</h2>
        <div class="pink">
            <!-- requried-jsfiles-for owl -->
        <link href="<?php echo e(asset('user_aset/css/owl.carousel.css')); ?>" rel="stylesheet">
        <script src="<?php echo e(asset('user_aset/js/owl.carousel.js')); ?>"></script>
            <script>
                $(document).ready(function() {
                    $("#owl-demo").owlCarousel({
                        items : 4,
                        lazyLoad : true,
                        autoPlay : true,
                        pagination : true,
                    });
                });
            </script>
        <!-- //requried-jsfiles-for owl -->
            <div id="owl-demo" class="owl-carousel text-center">
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <div class=" box-in">
            <div class=" grid_box">     
                        <a> <img src="<?php echo e(asset('img/kategori/'.$row->gambar)); ?>" class="img-responsive" alt="">
                                <div class="zoom-icon">
                                    <h5 class="text-center">
                                        Lihat Kategori <?php echo e($row->kategori); ?></h5>
                                    
                    
                        </div> </a>     
                   </div>
                    <!---->
                        <div class="grid_1 simpleCart_shelfItem">
                            <a href="<?php echo e(url('/semuaproduk/'.$row->id.'/kategori')); ?>" class="cup item_add"><span class=" item_price" ><?php echo e($row->kategori); ?></span></a>                  
                        </div>
                    <!---->
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="clearfix"> </div>
            </div>
            
        </div>
        
         </div>
    
        <!---->
    <div class="content-middle">
       <div class="product">
        <h2 class="new text-center">PRODUK TERBARU</h2>
        <div class="pink">
            <?php $__currentLoopData = $barangbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 box-in-at">
            <div class=" grid_box portfolio-wrapper">       
                    <a> 
                        <?php
                        $fotos = DB::table('gambar')
                        ->where('kode_barang',$row->kode_barang)
                        ->limit(1)
                        ->get();
                        ?>
                        <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img src="<?php echo e(asset('img/barang/'.$foto->nama)); ?>" class="img-responsive" alt="">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="zoom-icon">
                                    <ul class="in-by" style="padding-bottom:5px;">
                            <li><h5><b><?php echo e($row->barang); ?> - <?php echo e($row->total); ?> Pcs</b></h5></li>
                        </ul>
                                    <ul class="in-by">
                                        <li><h5>Ukuran :</h5></li>
                                        <?php
                                        $detail = DB::table('tb_barangs')
                                        ->where('kode',$row->kode_barang)
                                        ->get();
                                        ?>
                                        <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                   
                                        <li><span><?php echo e($dtl->warna); ?></span></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                    
                    
                        <ul class="in-by-color">
                            <li><h5>Warna :</h5></li>   
                            <?php
                                        $detail = DB::table('tb_barangs')
                                        ->select(DB::raw('tb_barangs.kode,tb_varian.hex'))
                                        ->leftjoin('tb_varian','tb_varian.kode_v','=','tb_barangs.kode_v')
                                        ->where('kode',$row->kode_barang)
                                        ->get();
                                        ?>
                                        <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                   
                                        <li><span class="color" style="background-color: <?php echo e($dtl->hex); ?>;"> </span></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </ul>

                        </div> </a>     
                   </div>
                <!---->
                        <div class="grid_1 simpleCart_shelfItem">
                            <a href="<?php echo e(url('/detailbarang/'.$row->id)); ?>" class="cup item_add"><span class=" item_price" >
                             <?php if($row->diskon > 0): ?>
                                <?php
                                $hargadiskon = $row->harga_barang - ($row->diskon/100*$row->harga_barang); 
                                ?>
                                <?php echo e("Rp ". number_format($hargadiskon,0,',','.')); ?>

                            <?php else: ?>
                                <?php echo e("Rp ". number_format($row->harga_barang,0,',','.')); ?>

                            <?php endif; ?></span></a>                  
                        </div>
                    <!---->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="clearfix"> </div>
        </div>
        </div>
    </div>
    <!---->
        <h2 class="new text-center">ARTIKEL TERBARU</h2>
        <br>
        <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="content-bottom">
                <div class="col-md-12 latter">
                    <img src="<?php echo e(asset('img/artikel/'.$art->gambar)); ?>" alt="" width="100%">
                    <br><br>
                    <h6><?php echo e($art->judul); ?></h6>
                    <br><br>

                    <p><?php echo substr($art->isi,0,200); ?></p>
                    <br>
                    <span class="label label-primary" style="background-color: #fa7455;">
                        <i class="fa fa-eye"></i> <?php echo e($art->dilihat); ?>

                    </span>&nbsp;
                    <span class="label label-primary" style="background-color: #fa7455;">
                        <i class="fa fa-calendar"></i> <?php echo e($art->tgl); ?>

                    </span>
                    &nbsp;
                    <span class="label label-primary" style="background-color: #fa7455;">
                        <i class="fa fa-tag"></i> <?php echo e($art->nama); ?>

                    </span>
                    
                    <br>
                    <div class="text-center">
                        <button class="btn btn-block tombol">
                        Lanjut Baca
                    </button>
                        
                    </div>
                    <div class="clearfix"> </div>
                </div>
         
                    <div class="clearfix"> </div>
            </div>
        </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12 col-sm-12 text-center">
                <br>
                    <button class="tombol">
                        Lihat Semua Artikel
                    </button>
                </div>
   <?php $__env->stopSection(); ?>
    
    
<?php echo $__env->make('layout/masteruser', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>