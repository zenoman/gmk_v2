<?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->startSection('title',$webset->webName); ?>
    <?php $__env->startSection('favicon'); ?>
        <link rel="shortcut icon" type="image" href="<?php echo e(asset('img/setting/'.$webset->ico)); ?>">
    <?php $__env->stopSection(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/vendor/datatables-plugins/dataTables.bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/datatables-responsive/dataTables.responsive.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper">    
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Barang</h1>
                </div>
            </div>
            <div class="row">
                    <div class="col-lg-12">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo e(session('status')); ?>

                    </div>
                    <?php elseif(session('statuserror')): ?>
                    <div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo e(session('statuserror')); ?>

                    </div>
                    <?php endif; ?>
                	
                    <a href="<?php echo e(url('barang/create')); ?>" class="btn btn-primary"><i class="fa fa-pencil"></i> Tambah Data</a>

                     <a href="<?php echo e(url('barang/importexcel')); ?>" class="btn btn-success"><i class="fa fa-file-excel-o"></i> Import Excel</a>

                    <button class="btn btn-info" data-toggle="modal" data-target="#searchModal">
                        <i class="fa fa-search"></i> Cari Data
                    </button>
                    <?php if($barangbelum > 0): ?>
                    <a href="<?php echo e(url('/barang/belumtampil')); ?>" class="btn btn-warning">Barang belum tampil(<?php echo e($barangbelum); ?>)</a>
                    <?php endif; ?>
                    <div class="modal fade" id="searchModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title" id="myModalLabel">Cari Data Spesifik Dari Semua Data</h4>
                                </div>
                                
                                <div class="modal-body">
                                    <form method="post" action="barang/cari">
                                        <div class="form-group">
                                            <input type="" name="cari" class="form-control" placeholder="cari berdasarkan nama barang" required>
                                        </div>
                                        <?php echo e(csrf_field()); ?>

                                </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-info">
                                        <i class="fa fa-search"></i> Cari Data
                                        </button>
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">
                                        Close
                                        </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    <br><br>   
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            List Data Barang
                        </div>
                        <div class="panel-body table-responsive">
                            <form method="post" action="<?php echo e(url('/barang/hapusbanyak')); ?>">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode</th>
                                        <th>Nama Barang</th>
                                        <th>Kategori</th>
                                        <th>Harga</th>
                                        <th>Diskon</th>
                                        <th>Stok</th>
                                        <th class="text-center">Aksi</th>
                                        <th>#</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i=0;?>
                                   	<?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $i++; ?>
                                    <tr>
                                   		<td><?php echo e($i); ?></td>
                                   		<td><?php echo e($row->kode_barang); ?></td>
                                        <td><?php echo e($row->barang); ?></td>
                                        <td><?php echo e($row->kategori); ?></td>
                                        <td>
                                        <?php echo e("Rp ". number_format($row->harga_barang,0,',','.')); ?> / <?php echo e("Rp ". number_format($row->harga_reseller,0,',','.')); ?>

                                        </td>
                                        <td>
                                            <?php if($row->diskon>0): ?>
                                            <?php echo e($row->diskon." %"); ?>

                                            <?php else: ?>
                                            -
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($row->total); ?></td>
                                        <td class="text-center">
                                            
                                            <a href="<?php echo e(url('barang/'.$row->id.'/edit')); ?>" class="btn btn-success"><i class="fa fa-wrench"></i></a>
                                            <a onclick="return confirm('Hapus Data ?')" href="<?php echo e(url('barang/'.$row->id.'/hapus')); ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                                        </td>
                                        <td align="center" bgcolor="#FFFFFF"><input name="kodebarang[]" type="checkbox" id="checkbox[]" value="<?php echo e($row->id); ?>"></td>
                                   	</tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </tbody>
                            </table>
                            <div class="pull-right">
                            <input onclick="return confirm('Hapus Data Terpilih ?')" type="submit" name="submit" class="btn btn-block btn-danger" value="hapus data terpilih">    
                            </div>
                            <?php echo e(csrf_field()); ?>

                        </form>
                        <?php echo e($barang->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('js'); ?>
        <script src="<?php echo e(asset('assets/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendor/datatables-plugins/dataTables.bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendor/datatables-responsive/dataTables.responsive.js')); ?>"></script>
        <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true,
            "paging":false
        });
    });
    </script>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>