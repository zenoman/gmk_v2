<?php $__currentLoopData = $websettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('title',$webset->webName); ?>
<?php $__env->startSection('favicon'); ?>
<link rel="shortcut icon" type="image" href="<?php echo e(asset('img/setting/'.$webset->ico)); ?>">
<?php $__env->stopSection(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('content'); ?>
<script type="text/javascript">
     function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
</script>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Edit Data Setting</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                     <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Edit Data Dibawah Ini Sesuai Perintah !
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <?php $__currentLoopData = $setting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <form action="/setting/<?php echo e($row->idsettings); ?>" role="form" method="POST" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label>Nama Web</label>
                                            <input type="text" class="form-control" name="webname" value="<?php echo e($row->webName); ?>">
                                        </div>
                                         <?php if($errors->has('webname')): ?>
                                       <div class="alert alert-danger">
                                        <?php echo e($errors->first('webname')); ?>

                                         </div>
                                       <?php endif; ?>
                                      <div class="row">
                                           <div class="col-md-4 form-group">
                                            <label>Kontak1</label>
                                            <div class="form-group input-group">
                                            <span class="input-group-addon">+62</span>
                                            <input 
                                            type="text" 
                                            class="form-control" 
                                            name="kontak1" 
                                            value="<?php echo e(substr($row->kontak1,3)); ?>" 
                                            onkeypress="return isNumberKey(event)" 
                                            required>

                                            </div>
                                            
                                         <?php if($errors->has('kontak1')): ?>
                                       <div class="alert alert-danger">
                                        <?php echo e($errors->first('kontak1')); ?>

                                         </div>
                                       <?php endif; ?>
                                        </div>

                                        <div class="col-md-4 form-group">
                                            <label>Kontak2</label>
                                            <div class="form-group input-group">
                                            <span class="input-group-addon">+62</span>
                                            <input 
                                            type="text" 
                                            class="form-control" 
                                            name="kontak2" 
                                            value="<?php echo e(substr($row->kontak2,3)); ?>" 
                                            onkeypress="return isNumberKey(event)" 
                                            required>

                                            </div>
                                             <?php if($errors->has('kontak2')): ?>
                                       <div class="alert alert-danger">
                                        <?php echo e($errors->first('kontak2')); ?>

                                         </div>
                                       <?php endif; ?>
                                        </div>
                                        <div class="col-md-4 form-group">
                                            <label>Kontak3</label>
                                            <div class="form-group input-group">
                                            <span class="input-group-addon">+62</span>
                                            <input 
                                            type="text" 
                                            class="form-control" 
                                            name="kontak3" 
                                            value="<?php echo e(substr($row->kontak3,3)); ?>" 
                                            onkeypress="return isNumberKey(event)" 
                                            required>
                                            </div>
                                            <?php if($errors->has('kontak3')): ?>
                                       <div class="alert alert-danger">
                                        <?php echo e($errors->first('kontak3')); ?>

                                         </div>
                                       <?php endif; ?>
                                        </div>
                                       </div>
                                         <div class="form-group">
                                            <label>Email</label>
                                            <input type="text" class="form-control" name="email" value="<?php echo e($row->email); ?>">
                                        </div>
                                         <?php if($errors->has('email')): ?>
                                       <div class="alert alert-danger">
                                        <?php echo e($errors->first('email')); ?>

                                         </div>
                                       <?php endif; ?>
                                       <div class="form-group">
                                            <label>Meta</label>
                                            <input type="text" class="form-control" name="meta" value="<?php echo e($row->meta); ?>">
                                        </div>
                                         <?php if($errors->has('meta')): ?>
                                       <div class="alert alert-danger">
                                        <?php echo e($errors->first('meta')); ?>

                                         </div>
                                       <?php endif; ?>

                                       <div class="form-group">
                                            <label>Batas hari Pemesana</label>
                                            <input type="text" class="form-control" name="kadaluarsa" value="<?php echo e($row->max_tgl); ?>" onkeypress="return isNumberKey(event)">
                                        </div>
                                        <div class="form-group">
                                            <label>Alamat</label>
                                            <input type="text" class="form-control" name="alamat" value="<?php echo e($row->alamat); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Deskripsi</label>
                                            <textarea class="form-control" name="keterangan" rows="4">
                                                <?php echo e($row->keterangan); ?>

                                            </textarea>
                                        </div>
                                        <div class="form-group">
                                            <label>Peraturan Belanja</label>
                                            <textarea class="form-control" name="peraturan" rows="8" id="editor">
                                                <?php echo e($row->peraturan); ?>

                                            </textarea>
                                        </div>
                                             <div class="form-group">
                                            <label>Ganti Icon</label><p>
                                            <img src="<?php echo e(asset('img/setting/'.$row->ico)); ?>" width="10%">
                                            <input type="file" name="ico" accept="image/*">
                                        </div>
                                        <?php if($errors->has('ico')): ?>
                                       <div class="alert alert-danger">
                                        <?php echo e($errors->first('ico')); ?>

                                         </div>
                                       <?php endif; ?>
                                             <div class="form-group">
                                            <label>Ganti Logo</label><p>
                                            <img src="<?php echo e(asset('img/setting/'.$row->logo)); ?>" width="30%">
                                            <input type="file" name="logo" accept="image/*">
                                        </div>
                                          <?php if($errors->has('logo')): ?>
                                       <div class="alert alert-danger">
                                        <?php echo e($errors->first('logo')); ?>

                                         </div>
                                       <?php endif; ?>


                                         <?php echo e(csrf_field()); ?>

                                      <div class="text-left">
                                        <input type="hidden" name="_method" value="PUT">
                                        <input class="btn btn-primary" type="submit" name="submit" value="simpan">
                                      
                          <a onclick="window.history.go(-1);" class="btn btn-danger">Kembali</a>  
                        </div>
                                    </form>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                              
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('js'); ?>
        <script src="<?php echo e(asset('assets/js/ckeditor.js')); ?>"></script>
  <script>
    ClassicEditor
    .create( document.querySelector('#editor'),{
        toolbar: [ 'heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote' ],
        heading: {
            options: [
                { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
                { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
                { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' }
            ]
        }
    })
    .catch( error => {
        console.log( error );
    } );
    </script>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>