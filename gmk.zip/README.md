gmk_v2
