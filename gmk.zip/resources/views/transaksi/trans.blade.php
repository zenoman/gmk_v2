@extends('layout.master')
@section('css')
<link rel="stylesheet" href="{{asset('css/jquery-ui.min.css')}}">
<style>
.padd{
    margin-top:20px;
}
</style>
@endsection
@section('content')
<div id="page-wrapper">
    <div class="row">
        <trans></trans>
    </div>
    
</div>
@endsection