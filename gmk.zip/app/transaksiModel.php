<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class transaksiModel extends Model
{
    //
}
