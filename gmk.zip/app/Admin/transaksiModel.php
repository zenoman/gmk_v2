<?php

namespace App\Admin;

use Illuminate\Database\Eloquent\Model;

class transaksiModel extends Model
{
    //
}
